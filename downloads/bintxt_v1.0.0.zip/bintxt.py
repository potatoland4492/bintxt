#!/usr/bin/python3

def b2t(binary):
  binary_values = binary.split()
  ascii_string = ""
  for binary_value in binary_values:
    an_integer = int(binary_value, 2)
    ascii_character = chr(an_integer)
    ascii_string += ascii_character
    return(ascii_string)

def t2b(text):
  binary = ''.join('{:08b} '.format(ord(c)) for c in text)
  return(binary)